function posFalls = initializeFallObj(posFalls,noPosFalls)
posFalls(noPosFalls).noFrames = 0;
posFalls(noPosFalls).avgOrChg = 0;
posFalls(noPosFalls).avgAreaChg = 0;
posFalls(noPosFalls).speed = 0;
end